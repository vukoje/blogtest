﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Sinergija10.Examples.NotTestable.Tests
{
	[TestClass]
	public class UserTest
	{
		[TestMethod]
		public void SendMessageTest()
		{
			User user = new User("Mika", "Mika@example.com");
			user.SendMessage("Hello!");

			// Aaaaaand it's gone! :)
			// now what?
		}
	}
}
