﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Sinergija10.Examples.Spy.Tests
{
	[TestClass]
	public class UserTest
	{
		[TestMethod]
		public void SendMessageTest()
		{
			MailManagerSpy spy = new MailManagerSpy();
			User receiver = new User("Mika", "mika@example.com", spy);
			receiver.SendMessage("Hello!");

			Assert.AreEqual(1, spy.SentLog.Count);
			Assert.AreEqual("Hello!", spy.SentLog[0].Message);
			Assert.AreEqual("mika@example.com", spy.SentLog[0].ToEmailAddress);
		}
	}
}
