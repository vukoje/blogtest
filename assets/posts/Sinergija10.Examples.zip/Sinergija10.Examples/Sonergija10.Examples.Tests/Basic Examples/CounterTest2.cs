﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Sinergija10.Examples.Tests
{
	[TestClass]
	public class CounterTest2
	{
		private Counter Counter { get; set; }

		[TestInitialize]
		public void TestInitialize()
		{
			this.Counter = new Counter(); // Implicit setup
		}

		[TestCleanup]
		public void TestCleanup()
		{
			this.Counter = null; // cleanup
		}

		[TestMethod]
		public void IncreaseTest()
		{
			// Counter counter = new Counter(); // Inline Setup
			this.Counter.Increase(); // Exercise
			Assert.AreEqual(1, this.Counter.Number, "Number SHOULD be 1 after Increase."); // Verify
		}
	}
}
