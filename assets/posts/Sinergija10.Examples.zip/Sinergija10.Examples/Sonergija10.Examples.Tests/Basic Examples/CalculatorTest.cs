﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Sinergija10.Examples.Tests
{    
	[TestClass()]
	public class CalculatorTest
	{
		[TestMethod]
		public void SumTest()
		{
			int result = Calculator.Sum(1, 2);
			Assert.AreEqual(3, result, "Sum of 1 and 2 SHOULD be 3.");
		}
	}
}
