﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Sinergija10.Examples.Tests
{
	[TestClass]
	public class CounterTest
	{
		[TestMethod]
		public void ConstructorTest()
		{
			Counter counter = new Counter(); // Setup & Exercise
			Assert.AreEqual(0, counter.Number, "Number SHOULD be 0 after class createion."); // Verify
		}

		[TestMethod]
		public void IncreaseTest()
		{
			Counter counter = new Counter(); // Setup
			counter.Increase(); // Exercise
			Assert.AreEqual(1, counter.Number, "Number SHOULD be 1 after Increase."); // Verify
		}

		[TestMethod]
		public void DecreaseTest()
		{
			Counter counter = new Counter(); // Setup
			counter.Decrease(); // Exercise
			Assert.AreEqual(-1, counter.Number, "Number SHOULD be -1 after Decrease."); // Verify
		}

		[TestMethod]
		public void ResetTest()
		{
			Counter counter = new Counter(); // Setup
			counter.Increase(); // Setup!!!
			counter.Reset(); // Exercise
			Assert.AreEqual(0, counter.Number, "Number SHOULD be 0 after Reset."); // Verify
		}
	}
}
