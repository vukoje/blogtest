﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Sinergija10.Examples.Stub.Tests
{
	[TestClass]
	public class UserTest
	{
		[TestMethod]
		[ExpectedException(typeof(InvalidOperationException), "InvalidOperationException shuld be thrown if mail sending didn't succeed.")]
		public void SendMessageHardcodedStubTest()
		{
			MailManagerHardcodedStub stub = new MailManagerHardcodedStub();
			User receiver = new User("Mika", "mika@example.com", stub);
			receiver.SendMessage("Hello!");
		}

		[TestMethod]
		[ExpectedException(typeof(InvalidOperationException), "InvalidOperationException shuld be thrown if mail sending didn't succeed.")]
		public void SendMessageConfigurableStubTest()
		{
			MailManagerConfigurableStub stub = new MailManagerConfigurableStub();
			stub.Result = false;
			User receiver = new User("Mika", "mika@example.com", stub);
			receiver.SendMessage("Hello!");
		}


		[TestMethod]
		[ExpectedException(typeof(InvalidOperationException), "InvalidOperationException shuld be thrown if mail sending didn't succeed.")]
		public void SendMessageConfigurableStubAdvancedTest()
		{
			MailManagerConfigurableStubAdvanced stub = new MailManagerConfigurableStubAdvanced();
			stub.SendEmailHandler = delegate(Email mail)
			{
				// add logic here if needed
				return false;
			};

			User receiver = new User("Mika", "mika@example.com", stub);
			receiver.SendMessage("Hello!");
		}
	}
}
