﻿using System.Collections.ObjectModel;

namespace Sinergija10.Examples.Stub.Tests
{
	public class MailManagerHardcodedStub : IMailManager
	{
		public bool SendEmail(Email email)
		{
			return false;
		}
	}
}
