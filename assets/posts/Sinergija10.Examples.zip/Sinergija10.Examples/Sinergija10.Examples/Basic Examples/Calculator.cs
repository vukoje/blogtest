﻿
namespace Sinergija10.Examples
{
	public static class Calculator
	{
		public static int Sum(int x, int y)
		{
			return x + y;
		}
	}
}
