﻿
namespace Sinergija10.Examples
{
	public class MailManager : IMailManager
	{
		public bool SendEmail(Email email)
		{
			// logic for sending mail
			// ...

			return true;
		}
	}
}
