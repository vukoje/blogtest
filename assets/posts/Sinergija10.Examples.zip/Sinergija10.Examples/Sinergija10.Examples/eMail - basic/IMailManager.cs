﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sinergija10.Examples
{
	public interface IMailManager
	{
		bool SendEmail(Email email);
	}
}
